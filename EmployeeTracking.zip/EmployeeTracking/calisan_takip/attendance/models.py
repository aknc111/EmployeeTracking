from django.db import models
from django.conf import settings
from datetime import timedelta

class Attendance(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="attendance_records")
    date = models.DateField(auto_now_add=True)
    check_in = models.TimeField(null=True, blank=True)
    check_out = models.TimeField(null=True, blank=True)

    @property
    def total_worked_time(self):
        if self.check_in and self.check_out:
            delta = timedelta(
                hours=self.check_out.hour - self.check_in.hour,
                minutes=self.check_out.minute - self.check_in.minute
            )
            return delta
        return timedelta(0)

    def __str__(self):
        return f"{self.user.username} - {self.date}"


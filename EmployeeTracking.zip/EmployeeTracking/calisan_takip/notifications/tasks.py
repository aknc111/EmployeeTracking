﻿from celery import shared_task
from .models import Notification

@shared_task
def send_notification(user_id, message):
    notification = Notification.objects.create(
        recipient_id=user_id,
        message=message
    )
    # Bildirim gönderim işlemi
    return f'Notification sent to {user_id}'

from django.contrib import admin
from .models import Leave

@admin.register(Leave)
class LeaveAdmin(admin.ModelAdmin):
    list_display = ('user', 'leave_type', 'start_date', 'end_date', 'days_requested', 'is_approved')
    list_filter = ('leave_type', 'is_approved', 'start_date', 'end_date')
    search_fields = ('user__username', 'reason')
